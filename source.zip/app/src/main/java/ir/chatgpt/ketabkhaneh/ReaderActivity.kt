package ir.chatgpt.ketabkhaneh

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

class ReaderActivity : AppCompatActivity() {
    private lateinit var book: Book
    private lateinit var file: File
    private var books= mutableListOf<Book>()
    private var renderer: PdfRenderer?=null
    private var page=0
    private var fontSize=18
    private var night=false
    private lateinit var pageLabel: TextView
    private lateinit var content: FrameLayout
    private var epubChapters= mutableListOf<String>()
    private var epubZip: ZipFile?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        books=Store.load(this)
        book=books.firstOrNull { it.id==intent.getStringExtra("book_id") } ?: run { finish(); return }
        file=File(File(filesDir,"books"),book.fileName)
        title=book.title
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(6,6,6,6) }
        val bar=LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        fun button(label:String, action:()->Unit)=Button(this).apply { text=label; setOnClickListener { action() } }
        bar.addView(button("‹") { changePage(-1) })
        pageLabel=TextView(this).apply { gravity=Gravity.CENTER; textSize=14f }
        bar.addView(pageLabel,LinearLayout.LayoutParams(0,-2,1f))
        bar.addView(button("›") { changePage(1) })
        val tools=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        tools.addView(button("نشانک‌ها") { showBookmarks() })
        tools.addView(button("یادداشت") { addNote() })
        tools.addView(button("هایلایت") { addHighlight() })
        tools.addView(button("جست‌وجو") { searchInsideBook() })
        tools.addView(button("اندازه متن") { changeFont() })
        tools.addView(button("شب/روز") { night=!night; if(book.format=="epub") showEpubChapter() else Toast.makeText(this@ReaderActivity,"حالت شب برای PDF در این نسخه اعمال نمی‌شود",Toast.LENGTH_SHORT).show() })
        content=FrameLayout(this)
        root.addView(bar); root.addView(tools); root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        if(book.format=="pdf") openPdf() else openEpub()
    }

    private fun openPdf() {
        try {
            val pfd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY)
            renderer=PdfRenderer(pfd)
            page=book.progress.coerceIn(0,(renderer!!.pageCount-1).coerceAtLeast(0))
            showPdfPage()
        } catch(e:Exception) { error("باز کردن PDF ممکن نشد: ${e.message}") }
    }

    private fun showPdfPage() {
        val r=renderer ?: return
        if(r.pageCount==0) return
        page=page.coerceIn(0,r.pageCount-1)
        val pdfPage=r.openPage(page)
        val maxWidth=resources.displayMetrics.widthPixels.coerceAtLeast(500)
        val scale=(maxWidth.toFloat()/pdfPage.width).coerceIn(1f,2.2f)
        val bitmap=Bitmap.createBitmap((pdfPage.width*scale).toInt(),(pdfPage.height*scale).toInt(),Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        pdfPage.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); pdfPage.close()
        val image=ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER }
        content.removeAllViews(); content.addView(ScrollView(this).apply { addView(image) })
        pageLabel.text="صفحه ${page+1} از ${r.pageCount}"
        saveProgress()
    }

    private fun openEpub() {
        try {
            epubZip?.close()
            epubZip=ZipFile(file)
            val container=epubZip!!.getInputStream(epubZip!!.getEntry("META-INF/container.xml")).bufferedReader().readText()
            val opfPath=Regex("full-path=[\"']([^\"']+)").find(container)?.groupValues?.get(1) ?: throw Exception("ساختار EPUB نامعتبر است")
            val opf=epubZip!!.getInputStream(epubZip!!.getEntry(opfPath)).bufferedReader().readText()
            val base=opfPath.substringBeforeLast('/',"")
            val doc=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(opf.byteInputStream())
            val manifest=doc.getElementsByTagName("item")
            val hrefs=mutableMapOf<String,String>()
            for(i in 0 until manifest.length) {
                val n=manifest.item(i); val id=n.attributes.getNamedItem("id")?.nodeValue ?: continue
                val href=n.attributes.getNamedItem("href")?.nodeValue ?: continue
                hrefs[id]=if(base.isBlank()) href else "$base/$href"
            }
            val spine=doc.getElementsByTagName("itemref"); epubChapters.clear()
            for(i in 0 until spine.length) {
                val id=spine.item(i).attributes.getNamedItem("idref")?.nodeValue ?: continue
                hrefs[id]?.let { epubChapters.add(it) }
            }
            if(epubChapters.isEmpty()) throw Exception("فصل‌های EPUB پیدا نشد")
            page=book.progress.coerceIn(0,epubChapters.size-1)
            showEpubChapter()
        } catch(e:Exception) { error("خواندن EPUB ممکن نشد: ${e.message}") }
    }

    private fun showEpubChapter() {
        try {
            val zip=epubZip ?: return
            val chapter=epubChapters[page]
            val entry=zip.getEntry(chapter) ?: throw Exception("فصل پیدا نشد")
            val html=zip.getInputStream(entry).bufferedReader().readText()
            val bg=if(night) "#17191d" else "#ffffff"
            val fg=if(night) "#eeeeee" else "#222222"
            val css="<style>body{font-size:${fontSize}px!important;line-height:1.9;padding:18px;background:$bg;color:$fg;direction:auto}img{max-width:100%;height:auto}p{margin-bottom:1em}</style>"
            val styled=if(html.contains("</head>")) html.replace("</head>", "$css</head>") else "$css$html"
            val base=File(file.parent,chapter).parentFile
            val web=WebView(this).apply { settings.javaScriptEnabled=false; loadDataWithBaseURL("file://${base.absolutePath}/",styled,"text/html","UTF-8",null) }
            content.removeAllViews(); content.addView(web,FrameLayout.LayoutParams(-1,-1))
            pageLabel.text="فصل ${page+1} از ${epubChapters.size}"
            saveProgress()
        } catch(e:Exception) { error("خطا در نمایش فصل: ${e.message}") }
    }

    private fun changePage(delta:Int) {
        val total=if(book.format=="pdf") renderer?.pageCount ?: 1 else epubChapters.size
        page=(page+delta).coerceIn(0,(total-1).coerceAtLeast(0))
        if(book.format=="pdf") showPdfPage() else showEpubChapter()
    }

    private fun toggleBookmark() {
        if(book.bookmarks.contains(page)) book.bookmarks.remove(page) else book.bookmarks.add(page)
        Store.save(this,books)
        Toast.makeText(this,if(book.bookmarks.contains(page)) "نشانک ثبت شد" else "نشانک حذف شد",Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        if(book.bookmarks.isEmpty()) { Toast.makeText(this,"هنوز نشانکی ثبت نشده",Toast.LENGTH_SHORT).show(); return }
        val items=book.bookmarks.sorted().map { if(book.format=="pdf") "صفحه ${it+1}" else "فصل ${it+1}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("نشانک‌های ${book.title}").setItems(items) { _,which ->
            page=book.bookmarks.sorted()[which]
            if(book.format=="pdf") showPdfPage() else showEpubChapter()
        }.setNegativeButton("بستن",null).show()
    }

    private fun addNote() {
        val input=EditText(this).apply { hint="یادداشت این صفحه یا فصل را بنویس"; minLines=3 }
        AlertDialog.Builder(this).setTitle("یادداشت برای ${if(book.format=="pdf") "صفحه ${page+1}" else "فصل ${page+1}"}")
            .setView(input).setPositiveButton("ذخیره") { _,_ ->
                val value=input.text.toString().trim()
                if(value.isNotEmpty()) { book.notes.add("${if(book.format=="pdf") "صفحه" else "فصل"} ${page+1}: $value"); Store.save(this,books); Toast.makeText(this,"یادداشت ذخیره شد",Toast.LENGTH_SHORT).show() }
            }.setNeutralButton("نمایش یادداشت‌ها") { _,_ -> showNotes() }.setNegativeButton("لغو",null).show()
    }

    private fun showNotes() {
        val notes=book.notes
        AlertDialog.Builder(this).setTitle("یادداشت‌ها").setMessage(if(notes.isEmpty()) "یادداشتی ثبت نشده" else notes.joinToString("\n\n"))
            .setPositiveButton("بستن",null).show()
    }

    private fun changeFont() {
        val sizes=arrayOf("کوچک","معمولی","بزرگ","خیلی بزرگ")
        AlertDialog.Builder(this).setTitle("اندازه متن").setItems(sizes) { _,which ->
            fontSize=listOf(14,18,22,26)[which]
            if(book.format=="epub") showEpubChapter() else Toast.makeText(this,"تغییر اندازه متن مخصوص EPUB است؛ بزرگ‌نمایی PDF با حرکت دو انگشت انجام می‌شود",Toast.LENGTH_LONG).show()
        }.show()
    }


    private fun addHighlight() {
        val input=EditText(this).apply {
            hint="جمله یا بخشی از متن را اینجا وارد یا جای‌گذاری کن"
            minLines=3
        }
        AlertDialog.Builder(this).setTitle("ذخیره جمله هایلایت‌شده")
            .setMessage("در این نسخه، جمله را از متن کتاب انتخاب و اینجا جای‌گذاری کن.")
            .setView(input)
            .setPositiveButton("ذخیره") { _,_ ->
                val value=input.text.toString().trim()
                if(value.isNotEmpty()) {
                    book.highlights.add("${if(book.format=="pdf") "صفحه" else "فصل"} ${page+1}: $value")
                    Store.save(this,books)
                    Toast.makeText(this,"هایلایت ذخیره شد",Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("مشاهده هایلایت‌ها") { _,_ -> showHighlights() }
            .setNegativeButton("لغو",null).show()
    }

    private fun showHighlights() {
        AlertDialog.Builder(this).setTitle("جمله‌های ذخیره‌شده")
            .setMessage(if(book.highlights.isEmpty()) "هنوز جمله‌ای ذخیره نشده" else book.highlights.joinToString("\\n\\n"))
            .setPositiveButton("بستن",null).show()
    }

    private fun searchInsideBook() {
        val input=EditText(this).apply { hint="عبارت مورد جست‌وجو"; singleLine=true }
        AlertDialog.Builder(this).setTitle("جست‌وجو در متن کتاب").setView(input)
            .setPositiveButton("جست‌وجو") { _,_ ->
                val query=input.text.toString().trim()
                if(query.isNotEmpty()) runSearch(query)
            }.setNegativeButton("لغو",null).show()
    }

    private fun runSearch(query:String) {
        Thread {
            try {
                val text = if(book.format=="pdf") {
                    PDDocument.load(file).use { doc -> PDFTextStripper().getText(doc) }
                } else {
                    val zip=ZipFile(file)
                    try {
                        val container=zip.getInputStream(zip.getEntry("META-INF/container.xml")).bufferedReader().readText()
                        val opfPath=Regex("full-path=[\\\"']([^\\\"']+)").find(container)!!.groupValues[1]
                        val opfDoc=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(zip.getInputStream(zip.getEntry(opfPath)))
                        val base=opfPath.substringBeforeLast('/',"")
                        val manifest=opfDoc.getElementsByTagName("item")
                        val hrefs=mutableMapOf<String,String>()
                        for(i in 0 until manifest.length) {
                            val n=manifest.item(i); val id=n.attributes.getNamedItem("id")?.nodeValue ?: continue
                            val href=n.attributes.getNamedItem("href")?.nodeValue ?: continue
                            hrefs[id]=if(base.isBlank()) href else "$base/$href"
                        }
                        val spine=opfDoc.getElementsByTagName("itemref")
                        val sb=StringBuilder()
                        for(i in 0 until spine.length) {
                            val id=spine.item(i).attributes.getNamedItem("idref")?.nodeValue ?: continue
                            val path=hrefs[id] ?: continue
                            val e=zip.getEntry(path) ?: continue
                            val html=zip.getInputStream(e).bufferedReader().readText()
                            sb.append(html.replace(Regex("<script[\\s\\S]*?</script>|<style[\\s\\S]*?</style>","IGNORE_CASE")," ")
                                .replace(Regex("<[^>]+>")," ").replace("&nbsp;"," ").replace("&amp;","&")).append("\\n")
                        }
                        sb.toString()
                    } finally { zip.close() }
                }
                val matches=mutableListOf<String>()
                val lines=text.split(Regex("[\\r\\n]+"))
                for((i,line) in lines.withIndex()) {
                    val at=line.indexOf(query,ignoreCase=true)
                    if(at>=0) {
                        val start=(at-65).coerceAtLeast(0); val end=(at+query.length+95).coerceAtMost(line.length)
                        matches.add("بخش ${i+1}: "+line.substring(start,end).trim())
                        if(matches.size>=40) break
                    }
                }
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("نتایج جست‌وجو: ${matches.size}")
                        .setMessage(if(matches.isEmpty()) "عبارت پیدا نشد." else matches.joinToString("\\n\\n"))
                        .setPositiveButton("باشه",null).show()
                }
            } catch(e:Exception) {
                runOnUiThread { AlertDialog.Builder(this).setMessage("جست‌وجو انجام نشد: ${e.message}").setPositiveButton("باشه",null).show() }
            }
        }.start()
    }

    private fun saveProgress() { book.progress=page; book.lastOpened=System.currentTimeMillis(); Store.save(this,books) }
    private fun error(message:String) { AlertDialog.Builder(this).setMessage(message).setPositiveButton("باشه") { _,_ -> finish() }.show() }
    override fun onDestroy() { renderer?.close(); epubZip?.close(); super.onDestroy() }
}
