package ir.chatgpt.ketabkhaneh

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*\nimport android.graphics.Bitmap\nimport android.graphics.pdf.PdfRenderer\nimport android.os.ParcelFileDescriptor
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var categoryFilter: Spinner
    private var books = mutableListOf<Book>()
    private val PICK_BOOK = 41
    private var selectedCategory = "همه دسته‌ها"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        books = Store.load(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,12) }
        val header = TextView(this).apply {
            text = "کتابخانه من\nفضای شخصی مطالعه و نگهداری کتاب‌ها"
            textSize = 22f; gravity = Gravity.CENTER; setPadding(8,18,8,18)
        }
        search = EditText(this).apply { hint = "جست‌وجوی عنوان کتاب…"; singleLine = true }
        search.addTextChangedListener(SimpleTextWatcher { render() })
        categoryFilter = Spinner(this)
        categoryFilter.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selectedCategory = parent?.getItemAtPosition(position)?.toString() ?: "همه دسته‌ها"
                render()
            }
        }
        val add = Button(this).apply { text = "＋ افزودن PDF یا EPUB"; setOnClickListener { chooseBook() } }
        val stats = TextView(this).apply { textSize=14f; setPadding(4,8,4,8) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(header); root.addView(search); root.addView(categoryFilter); root.addView(add); root.addView(stats)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) { books=Store.load(this); render() } }

    private fun chooseBook() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "application/epub+zip", "application/octet-stream"))
        }
        startActivityForResult(i, PICK_BOOK)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_BOOK && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            val name = queryName(uri) ?: "کتاب"
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext !in listOf("pdf", "epub")) {
                Toast.makeText(this, "فقط PDF و EPUB پشتیبانی می‌شود", Toast.LENGTH_LONG).show(); return
            }
            try {
                val dest = File(filesDir, "books").apply { mkdirs() }
                val safeName = UUID.randomUUID().toString() + "." + ext
                contentResolver.openInputStream(uri)!!.use { input -> File(dest, safeName).outputStream().use { input.copyTo(it) } }
                books.add(Book(UUID.randomUUID().toString(), name.substringBeforeLast('.'), safeName, ext))
                Store.save(this, books); render()
            } catch (e: Exception) {
                Toast.makeText(this, "خطا در افزودن فایل: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun queryName(uri: Uri): String? = contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if(c.moveToFirst() && idx>=0) c.getString(idx) else null
    }

    private fun render() {
        if (!::list.isInitialized) return
        val cats = listOf("همه دسته‌ها") + books.map { it.category }.distinct().sorted()
        val oldPos = cats.indexOf(selectedCategory).coerceAtLeast(0)
        categoryFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        categoryFilter.setSelection(oldPos, false)
        val q = if (::search.isInitialized) search.text.toString().trim() else ""
        val shown = books.filter { (selectedCategory=="همه دسته‌ها" || it.category==selectedCategory) && it.title.contains(q,true) }
        list.removeAllViews()
        val stats = findStatsView()
        stats?.text = " ${books.size} کتاب  •  ${books.count { it.format=="pdf" }} PDF  •  ${books.count { it.format=="epub" }} EPUB"
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply {
                text=if(books.isEmpty()) "هنوز کتابی اضافه نکرده‌ای. از دکمه بالا فایل انتخاب کن." else "کتابی با این مشخصات پیدا نشد."
                textSize=16f; setPadding(8,30,8,8)
            })
        }
        shown.forEach { book ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,12) }
            val title=TextView(this).apply {
                text="📖  ${book.title}\n${book.format.uppercase()}  •  ${book.category}\n${if(book.format=="pdf") "صفحه" else "فصل"} ${book.progress+1}  •  ${book.bookmarks.size} نشانک  •  ${book.notes.size} یادداشت"
                textSize=16f
            }
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply { text="مطالعه"; setOnClickListener { startActivity(Intent(this@MainActivity,ReaderActivity::class.java).putExtra("book_id",book.id)) } })
            actions.addView(Button(this).apply { text="دسته‌بندی"; setOnClickListener { editCategory(book) } })
            actions.addView(Button(this).apply { text="حذف"; setOnClickListener { deleteBook(book) } })
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=android.view.Gravity.CENTER_VERTICAL }
            val cover = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(88,124).apply { rightMargin=12 }
                scaleType=ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFFE9EEF3.toInt())
                setImageResource(android.R.drawable.ic_menu_gallery)
            }
            if (book.format=="pdf") {
                try {
                    val pfd=ParcelFileDescriptor.open(File(File(filesDir,"books"),book.fileName),ParcelFileDescriptor.MODE_READ_ONLY)
                    val pdf=PdfRenderer(pfd); if(pdf.pageCount>0) {
                        val p=pdf.openPage(0); val bmp=Bitmap.createBitmap(176, (176f*p.height/p.width).toInt().coerceAtLeast(120), Bitmap.Config.ARGB_8888)
                        p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); cover.setImageBitmap(bmp); p.close()
                    }; pdf.close()
                } catch (_:Exception) {}
            } else {
                cover.setImageResource(android.R.drawable.ic_menu_agenda)
            }
            val details=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(title); addView(actions) }
            row.addView(cover); row.addView(details,LinearLayout.LayoutParams(0,-2,1f))
            card.addView(row); list.addView(card); list.addView(DividerView(this))
        }
    }

    private fun findStatsView(): TextView? {
        val root=findViewById<android.view.ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout ?: return null
        return (0 until root.childCount).map { root.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull { it.text.toString().contains(" کتاب") }
    }

    private fun editCategory(book: Book) {
        val input=EditText(this).apply { setText(book.category); hint="مثلاً تاریخ، رمان، علمی" }
        AlertDialog.Builder(this).setTitle("دسته‌بندی کتاب").setView(input)
            .setPositiveButton("ذخیره") { _,_ -> book.category=input.text.toString().ifBlank{"بدون دسته"}; Store.save(this,books); render() }
            .setNegativeButton("لغو",null).show()
    }

    private fun deleteBook(book: Book) {
        AlertDialog.Builder(this).setTitle("حذف کتاب").setMessage("«${book.title}» حذف شود؟")
            .setPositiveButton("حذف") { _,_ -> File(File(filesDir,"books"),book.fileName).delete(); books.remove(book); Store.save(this,books); render() }
            .setNegativeButton("انصراف",null).show()
    }
}

private class DividerView(context: android.content.Context) : android.view.View(context) {
    init { setBackgroundColor(0xFFE2E5E9.toInt()); layoutParams=LinearLayout.LayoutParams(-1,1).apply { topMargin=8; bottomMargin=8 } }
}
private class SimpleTextWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
