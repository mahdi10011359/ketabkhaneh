package ir.chatgpt.ketabkhaneh

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object Store {
    private const val PREF = "library_data"
    private const val BOOKS = "books"
    private val gson = Gson()
    fun load(context: Context): MutableList<Book> {
        val raw = context.getSharedPreferences(PREF, 0).getString(BOOKS, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<Book>>() {}.type
            gson.fromJson<MutableList<Book>>(raw, type) ?: mutableListOf()
        } catch (_: Exception) { mutableListOf() }
    }
    fun save(context: Context, books: List<Book>) {
        context.getSharedPreferences(PREF, 0).edit().putString(BOOKS, gson.toJson(books)).apply()
    }
}
