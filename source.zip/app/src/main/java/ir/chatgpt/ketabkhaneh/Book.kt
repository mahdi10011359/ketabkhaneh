package ir.chatgpt.ketabkhaneh

data class Book(
    var id: String,
    var title: String,
    var fileName: String,
    var format: String,
    var category: String = "بدون دسته",
    var progress: Int = 0,
    var bookmarks: MutableList<Int> = mutableListOf(),
    var notes: MutableList<String> = mutableListOf(),
    var highlights: MutableList<String> = mutableListOf(),
    var lastOpened: Long = System.currentTimeMillis()
)
